{
  "version": "1.2",
  "dbname": "CSI_Maker00001128.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001128.fasta",
  "number-of-letters": 15522,
  "number-of-sequences": 58,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 70623,
  "bytes-to-cache": 4739,
  "files": [
    "CSI_Maker00001128.fasta.ndb",
    "CSI_Maker00001128.fasta.nhr",
    "CSI_Maker00001128.fasta.nin",
    "CSI_Maker00001128.fasta.nog",
    "CSI_Maker00001128.fasta.nos",
    "CSI_Maker00001128.fasta.not",
    "CSI_Maker00001128.fasta.nsq",
    "CSI_Maker00001128.fasta.ntf",
    "CSI_Maker00001128.fasta.nto"
  ]
}
