{
  "version": "1.2",
  "dbname": "CSI_Maker00001140.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001140.fasta",
  "number-of-letters": 69855,
  "number-of-sequences": 77,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 92364,
  "bytes-to-cache": 19634,
  "files": [
    "CSI_Maker00001140.fasta.ndb",
    "CSI_Maker00001140.fasta.nhr",
    "CSI_Maker00001140.fasta.nin",
    "CSI_Maker00001140.fasta.nog",
    "CSI_Maker00001140.fasta.nos",
    "CSI_Maker00001140.fasta.not",
    "CSI_Maker00001140.fasta.nsq",
    "CSI_Maker00001140.fasta.ntf",
    "CSI_Maker00001140.fasta.nto"
  ]
}
