{
  "version": "1.2",
  "dbname": "CSI_Maker00000874.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000874.fasta",
  "number-of-letters": 18150,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 80005,
  "bytes-to-cache": 5779,
  "files": [
    "CSI_Maker00000874.fasta.ndb",
    "CSI_Maker00000874.fasta.nhr",
    "CSI_Maker00000874.fasta.nin",
    "CSI_Maker00000874.fasta.nog",
    "CSI_Maker00000874.fasta.nos",
    "CSI_Maker00000874.fasta.not",
    "CSI_Maker00000874.fasta.nsq",
    "CSI_Maker00000874.fasta.ntf",
    "CSI_Maker00000874.fasta.nto"
  ]
}
