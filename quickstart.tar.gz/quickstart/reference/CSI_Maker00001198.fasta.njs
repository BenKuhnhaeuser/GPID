{
  "version": "1.2",
  "dbname": "CSI_Maker00001198.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001198.fasta",
  "number-of-letters": 33240,
  "number-of-sequences": 84,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 83288,
  "bytes-to-cache": 9522,
  "files": [
    "CSI_Maker00001198.fasta.ndb",
    "CSI_Maker00001198.fasta.nhr",
    "CSI_Maker00001198.fasta.nin",
    "CSI_Maker00001198.fasta.nog",
    "CSI_Maker00001198.fasta.nos",
    "CSI_Maker00001198.fasta.not",
    "CSI_Maker00001198.fasta.nsq",
    "CSI_Maker00001198.fasta.ntf",
    "CSI_Maker00001198.fasta.nto"
  ]
}
