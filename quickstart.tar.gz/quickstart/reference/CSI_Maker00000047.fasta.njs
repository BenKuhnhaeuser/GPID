{
  "version": "1.2",
  "dbname": "CSI_Maker00000047.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000047.fasta",
  "number-of-letters": 38703,
  "number-of-sequences": 66,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 78087,
  "bytes-to-cache": 11087,
  "files": [
    "CSI_Maker00000047.fasta.ndb",
    "CSI_Maker00000047.fasta.nhr",
    "CSI_Maker00000047.fasta.nin",
    "CSI_Maker00000047.fasta.nog",
    "CSI_Maker00000047.fasta.nos",
    "CSI_Maker00000047.fasta.not",
    "CSI_Maker00000047.fasta.nsq",
    "CSI_Maker00000047.fasta.ntf",
    "CSI_Maker00000047.fasta.nto"
  ]
}
