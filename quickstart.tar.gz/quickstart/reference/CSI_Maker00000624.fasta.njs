{
  "version": "1.2",
  "dbname": "CSI_Maker00000624.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000624.fasta",
  "number-of-letters": 42732,
  "number-of-sequences": 88,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 86444,
  "bytes-to-cache": 12068,
  "files": [
    "CSI_Maker00000624.fasta.ndb",
    "CSI_Maker00000624.fasta.nhr",
    "CSI_Maker00000624.fasta.nin",
    "CSI_Maker00000624.fasta.nog",
    "CSI_Maker00000624.fasta.nos",
    "CSI_Maker00000624.fasta.not",
    "CSI_Maker00000624.fasta.nsq",
    "CSI_Maker00000624.fasta.ntf",
    "CSI_Maker00000624.fasta.nto"
  ]
}
