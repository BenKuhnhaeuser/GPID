{
  "version": "1.2",
  "dbname": "CSI_Maker00000875.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000875.fasta",
  "number-of-letters": 142671,
  "number-of-sequences": 85,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 111761,
  "bytes-to-cache": 37847,
  "files": [
    "CSI_Maker00000875.fasta.ndb",
    "CSI_Maker00000875.fasta.nhr",
    "CSI_Maker00000875.fasta.nin",
    "CSI_Maker00000875.fasta.nog",
    "CSI_Maker00000875.fasta.nos",
    "CSI_Maker00000875.fasta.not",
    "CSI_Maker00000875.fasta.nsq",
    "CSI_Maker00000875.fasta.ntf",
    "CSI_Maker00000875.fasta.nto"
  ]
}
