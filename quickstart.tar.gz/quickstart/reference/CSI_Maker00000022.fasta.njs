{
  "version": "1.2",
  "dbname": "CSI_Maker00000022.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000022.fasta",
  "number-of-letters": 20694,
  "number-of-sequences": 54,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 71315,
  "bytes-to-cache": 5989,
  "files": [
    "CSI_Maker00000022.fasta.ndb",
    "CSI_Maker00000022.fasta.nhr",
    "CSI_Maker00000022.fasta.nin",
    "CSI_Maker00000022.fasta.nog",
    "CSI_Maker00000022.fasta.nos",
    "CSI_Maker00000022.fasta.not",
    "CSI_Maker00000022.fasta.nsq",
    "CSI_Maker00000022.fasta.ntf",
    "CSI_Maker00000022.fasta.nto"
  ]
}
