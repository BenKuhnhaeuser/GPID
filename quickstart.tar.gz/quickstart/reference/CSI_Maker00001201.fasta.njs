{
  "version": "1.2",
  "dbname": "CSI_Maker00001201.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001201.fasta",
  "number-of-letters": 101838,
  "number-of-sequences": 81,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 101037,
  "bytes-to-cache": 27723,
  "files": [
    "CSI_Maker00001201.fasta.ndb",
    "CSI_Maker00001201.fasta.nhr",
    "CSI_Maker00001201.fasta.nin",
    "CSI_Maker00001201.fasta.nog",
    "CSI_Maker00001201.fasta.nos",
    "CSI_Maker00001201.fasta.not",
    "CSI_Maker00001201.fasta.nsq",
    "CSI_Maker00001201.fasta.ntf",
    "CSI_Maker00001201.fasta.nto"
  ]
}
