{
  "version": "1.2",
  "dbname": "CSI_Maker00000241.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000241.fasta",
  "number-of-letters": 12465,
  "number-of-sequences": 53,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 69052,
  "bytes-to-cache": 3920,
  "files": [
    "CSI_Maker00000241.fasta.ndb",
    "CSI_Maker00000241.fasta.nhr",
    "CSI_Maker00000241.fasta.nin",
    "CSI_Maker00000241.fasta.nog",
    "CSI_Maker00000241.fasta.nos",
    "CSI_Maker00000241.fasta.not",
    "CSI_Maker00000241.fasta.nsq",
    "CSI_Maker00000241.fasta.ntf",
    "CSI_Maker00000241.fasta.nto"
  ]
}
