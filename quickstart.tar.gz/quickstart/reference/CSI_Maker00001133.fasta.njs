{
  "version": "1.2",
  "dbname": "CSI_Maker00001133.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001133.fasta",
  "number-of-letters": 211248,
  "number-of-sequences": 88,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 128918,
  "bytes-to-cache": 54542,
  "files": [
    "CSI_Maker00001133.fasta.ndb",
    "CSI_Maker00001133.fasta.nhr",
    "CSI_Maker00001133.fasta.nin",
    "CSI_Maker00001133.fasta.nog",
    "CSI_Maker00001133.fasta.nos",
    "CSI_Maker00001133.fasta.not",
    "CSI_Maker00001133.fasta.nsq",
    "CSI_Maker00001133.fasta.ntf",
    "CSI_Maker00001133.fasta.nto"
  ]
}
