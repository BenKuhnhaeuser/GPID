{
  "version": "1.2",
  "dbname": "CSI_Maker00000738.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000738.fasta",
  "number-of-letters": 134601,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 110399,
  "bytes-to-cache": 36179,
  "files": [
    "CSI_Maker00000738.fasta.ndb",
    "CSI_Maker00000738.fasta.nhr",
    "CSI_Maker00000738.fasta.nin",
    "CSI_Maker00000738.fasta.nog",
    "CSI_Maker00000738.fasta.nos",
    "CSI_Maker00000738.fasta.not",
    "CSI_Maker00000738.fasta.nsq",
    "CSI_Maker00000738.fasta.ntf",
    "CSI_Maker00000738.fasta.nto"
  ]
}
