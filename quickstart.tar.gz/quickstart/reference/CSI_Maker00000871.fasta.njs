{
  "version": "1.2",
  "dbname": "CSI_Maker00000871.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000871.fasta",
  "number-of-letters": 23514,
  "number-of-sequences": 80,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 80361,
  "bytes-to-cache": 7191,
  "files": [
    "CSI_Maker00000871.fasta.ndb",
    "CSI_Maker00000871.fasta.nhr",
    "CSI_Maker00000871.fasta.nin",
    "CSI_Maker00000871.fasta.nog",
    "CSI_Maker00000871.fasta.nos",
    "CSI_Maker00000871.fasta.not",
    "CSI_Maker00000871.fasta.nsq",
    "CSI_Maker00000871.fasta.ntf",
    "CSI_Maker00000871.fasta.nto"
  ]
}
