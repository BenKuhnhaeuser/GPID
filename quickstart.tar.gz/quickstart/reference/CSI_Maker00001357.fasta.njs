{
  "version": "1.2",
  "dbname": "CSI_Maker00001357.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001357.fasta",
  "number-of-letters": 133521,
  "number-of-sequences": 86,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 110153,
  "bytes-to-cache": 36073,
  "files": [
    "CSI_Maker00001357.fasta.ndb",
    "CSI_Maker00001357.fasta.nhr",
    "CSI_Maker00001357.fasta.nin",
    "CSI_Maker00001357.fasta.nog",
    "CSI_Maker00001357.fasta.nos",
    "CSI_Maker00001357.fasta.not",
    "CSI_Maker00001357.fasta.nsq",
    "CSI_Maker00001357.fasta.ntf",
    "CSI_Maker00001357.fasta.nto"
  ]
}
