{
  "version": "1.2",
  "dbname": "CSI_Maker00000032.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000032.fasta",
  "number-of-letters": 76173,
  "number-of-sequences": 84,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 94442,
  "bytes-to-cache": 20654,
  "files": [
    "CSI_Maker00000032.fasta.ndb",
    "CSI_Maker00000032.fasta.nhr",
    "CSI_Maker00000032.fasta.nin",
    "CSI_Maker00000032.fasta.nog",
    "CSI_Maker00000032.fasta.nos",
    "CSI_Maker00000032.fasta.not",
    "CSI_Maker00000032.fasta.nsq",
    "CSI_Maker00000032.fasta.ntf",
    "CSI_Maker00000032.fasta.nto"
  ]
}
