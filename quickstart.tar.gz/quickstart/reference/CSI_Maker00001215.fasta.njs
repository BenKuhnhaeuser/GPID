{
  "version": "1.2",
  "dbname": "CSI_Maker00001215.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001215.fasta",
  "number-of-letters": 900,
  "number-of-sequences": 10,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 51145,
  "bytes-to-cache": 495,
  "files": [
    "CSI_Maker00001215.fasta.ndb",
    "CSI_Maker00001215.fasta.nhr",
    "CSI_Maker00001215.fasta.nin",
    "CSI_Maker00001215.fasta.nog",
    "CSI_Maker00001215.fasta.nos",
    "CSI_Maker00001215.fasta.not",
    "CSI_Maker00001215.fasta.nsq",
    "CSI_Maker00001215.fasta.ntf",
    "CSI_Maker00001215.fasta.nto"
  ]
}
