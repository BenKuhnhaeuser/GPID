{
  "version": "1.2",
  "dbname": "CSI_Maker00001464.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001464.fasta",
  "number-of-letters": 25428,
  "number-of-sequences": 53,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 72841,
  "bytes-to-cache": 7699,
  "files": [
    "CSI_Maker00001464.fasta.ndb",
    "CSI_Maker00001464.fasta.nhr",
    "CSI_Maker00001464.fasta.nin",
    "CSI_Maker00001464.fasta.nog",
    "CSI_Maker00001464.fasta.nos",
    "CSI_Maker00001464.fasta.not",
    "CSI_Maker00001464.fasta.nsq",
    "CSI_Maker00001464.fasta.ntf",
    "CSI_Maker00001464.fasta.nto"
  ]
}
