{
  "version": "1.2",
  "dbname": "CSI_Maker00000583.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000583.fasta",
  "number-of-letters": 13698,
  "number-of-sequences": 42,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 67679,
  "bytes-to-cache": 4121,
  "files": [
    "CSI_Maker00000583.fasta.ndb",
    "CSI_Maker00000583.fasta.nhr",
    "CSI_Maker00000583.fasta.nin",
    "CSI_Maker00000583.fasta.nog",
    "CSI_Maker00000583.fasta.nos",
    "CSI_Maker00000583.fasta.not",
    "CSI_Maker00000583.fasta.nsq",
    "CSI_Maker00000583.fasta.ntf",
    "CSI_Maker00000583.fasta.nto"
  ]
}
