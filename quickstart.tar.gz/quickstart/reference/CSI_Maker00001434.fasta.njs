{
  "version": "1.2",
  "dbname": "CSI_Maker00001434.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001434.fasta",
  "number-of-letters": 86691,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 97757,
  "bytes-to-cache": 23531,
  "files": [
    "CSI_Maker00001434.fasta.ndb",
    "CSI_Maker00001434.fasta.nhr",
    "CSI_Maker00001434.fasta.nin",
    "CSI_Maker00001434.fasta.nog",
    "CSI_Maker00001434.fasta.nos",
    "CSI_Maker00001434.fasta.not",
    "CSI_Maker00001434.fasta.nsq",
    "CSI_Maker00001434.fasta.ntf",
    "CSI_Maker00001434.fasta.nto"
  ]
}
