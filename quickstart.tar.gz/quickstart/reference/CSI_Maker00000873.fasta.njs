{
  "version": "1.2",
  "dbname": "CSI_Maker00000873.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000873.fasta",
  "number-of-letters": 133521,
  "number-of-sequences": 89,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 110153,
  "bytes-to-cache": 35615,
  "files": [
    "CSI_Maker00000873.fasta.ndb",
    "CSI_Maker00000873.fasta.nhr",
    "CSI_Maker00000873.fasta.nin",
    "CSI_Maker00000873.fasta.nog",
    "CSI_Maker00000873.fasta.nos",
    "CSI_Maker00000873.fasta.not",
    "CSI_Maker00000873.fasta.nsq",
    "CSI_Maker00000873.fasta.ntf",
    "CSI_Maker00000873.fasta.nto"
  ]
}
