{
  "version": "1.2",
  "dbname": "CSI_Maker00000552.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000552.fasta",
  "number-of-letters": 60183,
  "number-of-sequences": 69,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 84001,
  "bytes-to-cache": 16471,
  "files": [
    "CSI_Maker00000552.fasta.ndb",
    "CSI_Maker00000552.fasta.nhr",
    "CSI_Maker00000552.fasta.nin",
    "CSI_Maker00000552.fasta.nog",
    "CSI_Maker00000552.fasta.nos",
    "CSI_Maker00000552.fasta.not",
    "CSI_Maker00000552.fasta.nsq",
    "CSI_Maker00000552.fasta.ntf",
    "CSI_Maker00000552.fasta.nto"
  ]
}
