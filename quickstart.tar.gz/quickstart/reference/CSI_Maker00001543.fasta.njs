{
  "version": "1.2",
  "dbname": "CSI_Maker00001543.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001543.fasta",
  "number-of-letters": 14802,
  "number-of-sequences": 49,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 69325,
  "bytes-to-cache": 4749,
  "files": [
    "CSI_Maker00001543.fasta.ndb",
    "CSI_Maker00001543.fasta.nhr",
    "CSI_Maker00001543.fasta.nin",
    "CSI_Maker00001543.fasta.nog",
    "CSI_Maker00001543.fasta.nos",
    "CSI_Maker00001543.fasta.not",
    "CSI_Maker00001543.fasta.nsq",
    "CSI_Maker00001543.fasta.ntf",
    "CSI_Maker00001543.fasta.nto"
  ]
}
