{
  "version": "1.2",
  "dbname": "CSI_Maker00000957.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000957.fasta",
  "number-of-letters": 94836,
  "number-of-sequences": 81,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 99349,
  "bytes-to-cache": 26011,
  "files": [
    "CSI_Maker00000957.fasta.ndb",
    "CSI_Maker00000957.fasta.nhr",
    "CSI_Maker00000957.fasta.nin",
    "CSI_Maker00000957.fasta.nog",
    "CSI_Maker00000957.fasta.nos",
    "CSI_Maker00000957.fasta.not",
    "CSI_Maker00000957.fasta.nsq",
    "CSI_Maker00000957.fasta.ntf",
    "CSI_Maker00000957.fasta.nto"
  ]
}
