{
  "version": "1.2",
  "dbname": "CSI_Maker00000214.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000214.fasta",
  "number-of-letters": 19065,
  "number-of-sequences": 59,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 72056,
  "bytes-to-cache": 6062,
  "files": [
    "CSI_Maker00000214.fasta.ndb",
    "CSI_Maker00000214.fasta.nhr",
    "CSI_Maker00000214.fasta.nin",
    "CSI_Maker00000214.fasta.nog",
    "CSI_Maker00000214.fasta.nos",
    "CSI_Maker00000214.fasta.not",
    "CSI_Maker00000214.fasta.nsq",
    "CSI_Maker00000214.fasta.ntf",
    "CSI_Maker00000214.fasta.nto"
  ]
}
