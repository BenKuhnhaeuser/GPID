{
  "version": "1.2",
  "dbname": "CSI_Maker00000763.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000763.fasta",
  "number-of-letters": 195132,
  "number-of-sequences": 89,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 126913,
  "bytes-to-cache": 52391,
  "files": [
    "CSI_Maker00000763.fasta.ndb",
    "CSI_Maker00000763.fasta.nhr",
    "CSI_Maker00000763.fasta.nin",
    "CSI_Maker00000763.fasta.nog",
    "CSI_Maker00000763.fasta.nos",
    "CSI_Maker00000763.fasta.not",
    "CSI_Maker00000763.fasta.nsq",
    "CSI_Maker00000763.fasta.ntf",
    "CSI_Maker00000763.fasta.nto"
  ]
}
