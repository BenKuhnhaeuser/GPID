{
  "version": "1.2",
  "dbname": "CSI_Maker00001277.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001277.fasta",
  "number-of-letters": 43191,
  "number-of-sequences": 84,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 86018,
  "bytes-to-cache": 12234,
  "files": [
    "CSI_Maker00001277.fasta.ndb",
    "CSI_Maker00001277.fasta.nhr",
    "CSI_Maker00001277.fasta.nin",
    "CSI_Maker00001277.fasta.nog",
    "CSI_Maker00001277.fasta.nos",
    "CSI_Maker00001277.fasta.not",
    "CSI_Maker00001277.fasta.nsq",
    "CSI_Maker00001277.fasta.ntf",
    "CSI_Maker00001277.fasta.nto"
  ]
}
