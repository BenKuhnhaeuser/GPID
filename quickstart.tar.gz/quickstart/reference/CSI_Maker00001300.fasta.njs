{
  "version": "1.2",
  "dbname": "CSI_Maker00001300.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001300.fasta",
  "number-of-letters": 53559,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 89391,
  "bytes-to-cache": 15171,
  "files": [
    "CSI_Maker00001300.fasta.ndb",
    "CSI_Maker00001300.fasta.nhr",
    "CSI_Maker00001300.fasta.nin",
    "CSI_Maker00001300.fasta.nog",
    "CSI_Maker00001300.fasta.nos",
    "CSI_Maker00001300.fasta.not",
    "CSI_Maker00001300.fasta.nsq",
    "CSI_Maker00001300.fasta.ntf",
    "CSI_Maker00001300.fasta.nto"
  ]
}
