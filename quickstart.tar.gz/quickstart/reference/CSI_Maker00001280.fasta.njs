{
  "version": "1.2",
  "dbname": "CSI_Maker00001280.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001280.fasta",
  "number-of-letters": 68310,
  "number-of-sequences": 84,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 92763,
  "bytes-to-cache": 19007,
  "files": [
    "CSI_Maker00001280.fasta.ndb",
    "CSI_Maker00001280.fasta.nhr",
    "CSI_Maker00001280.fasta.nin",
    "CSI_Maker00001280.fasta.nog",
    "CSI_Maker00001280.fasta.nos",
    "CSI_Maker00001280.fasta.not",
    "CSI_Maker00001280.fasta.nsq",
    "CSI_Maker00001280.fasta.ntf",
    "CSI_Maker00001280.fasta.nto"
  ]
}
