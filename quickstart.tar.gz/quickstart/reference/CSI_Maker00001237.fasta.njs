{
  "version": "1.2",
  "dbname": "CSI_Maker00001237.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001237.fasta",
  "number-of-letters": 39120,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 85358,
  "bytes-to-cache": 11132,
  "files": [
    "CSI_Maker00001237.fasta.ndb",
    "CSI_Maker00001237.fasta.nhr",
    "CSI_Maker00001237.fasta.nin",
    "CSI_Maker00001237.fasta.nog",
    "CSI_Maker00001237.fasta.nos",
    "CSI_Maker00001237.fasta.not",
    "CSI_Maker00001237.fasta.nsq",
    "CSI_Maker00001237.fasta.ntf",
    "CSI_Maker00001237.fasta.nto"
  ]
}
