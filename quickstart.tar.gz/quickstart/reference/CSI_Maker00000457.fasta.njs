{
  "version": "1.2",
  "dbname": "CSI_Maker00000457.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000457.fasta",
  "number-of-letters": 57387,
  "number-of-sequences": 81,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 90161,
  "bytes-to-cache": 16843,
  "files": [
    "CSI_Maker00000457.fasta.ndb",
    "CSI_Maker00000457.fasta.nhr",
    "CSI_Maker00000457.fasta.nin",
    "CSI_Maker00000457.fasta.nog",
    "CSI_Maker00000457.fasta.nos",
    "CSI_Maker00000457.fasta.not",
    "CSI_Maker00000457.fasta.nsq",
    "CSI_Maker00000457.fasta.ntf",
    "CSI_Maker00000457.fasta.nto"
  ]
}
