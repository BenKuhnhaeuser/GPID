{
  "version": "1.2",
  "dbname": "CSI_Maker00000547.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000547.fasta",
  "number-of-letters": 215598,
  "number-of-sequences": 82,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 131253,
  "bytes-to-cache": 57777,
  "files": [
    "CSI_Maker00000547.fasta.ndb",
    "CSI_Maker00000547.fasta.nhr",
    "CSI_Maker00000547.fasta.nin",
    "CSI_Maker00000547.fasta.nog",
    "CSI_Maker00000547.fasta.nos",
    "CSI_Maker00000547.fasta.not",
    "CSI_Maker00000547.fasta.nsq",
    "CSI_Maker00000547.fasta.ntf",
    "CSI_Maker00000547.fasta.nto"
  ]
}
