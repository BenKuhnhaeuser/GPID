{
  "version": "1.2",
  "dbname": "CSI_Maker00000181.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000181.fasta",
  "number-of-letters": 163794,
  "number-of-sequences": 89,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 117461,
  "bytes-to-cache": 42939,
  "files": [
    "CSI_Maker00000181.fasta.ndb",
    "CSI_Maker00000181.fasta.nhr",
    "CSI_Maker00000181.fasta.nin",
    "CSI_Maker00000181.fasta.nog",
    "CSI_Maker00000181.fasta.nos",
    "CSI_Maker00000181.fasta.not",
    "CSI_Maker00000181.fasta.nsq",
    "CSI_Maker00000181.fasta.ntf",
    "CSI_Maker00000181.fasta.nto"
  ]
}
