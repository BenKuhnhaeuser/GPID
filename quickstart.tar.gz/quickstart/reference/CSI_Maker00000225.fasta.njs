{
  "version": "1.2",
  "dbname": "CSI_Maker00000225.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000225.fasta",
  "number-of-letters": 60495,
  "number-of-sequences": 82,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 89997,
  "bytes-to-cache": 16509,
  "files": [
    "CSI_Maker00000225.fasta.ndb",
    "CSI_Maker00000225.fasta.nhr",
    "CSI_Maker00000225.fasta.nin",
    "CSI_Maker00000225.fasta.nog",
    "CSI_Maker00000225.fasta.nos",
    "CSI_Maker00000225.fasta.not",
    "CSI_Maker00000225.fasta.nsq",
    "CSI_Maker00000225.fasta.ntf",
    "CSI_Maker00000225.fasta.nto"
  ]
}
