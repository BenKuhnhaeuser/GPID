{
  "version": "1.2",
  "dbname": "CSI_Maker00000815.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000815.fasta",
  "number-of-letters": 4563,
  "number-of-sequences": 37,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 56325,
  "bytes-to-cache": 1739,
  "files": [
    "CSI_Maker00000815.fasta.ndb",
    "CSI_Maker00000815.fasta.nhr",
    "CSI_Maker00000815.fasta.nin",
    "CSI_Maker00000815.fasta.nog",
    "CSI_Maker00000815.fasta.nos",
    "CSI_Maker00000815.fasta.not",
    "CSI_Maker00000815.fasta.nsq",
    "CSI_Maker00000815.fasta.ntf",
    "CSI_Maker00000815.fasta.nto"
  ]
}
