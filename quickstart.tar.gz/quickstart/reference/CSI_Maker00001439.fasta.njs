{
  "version": "1.2",
  "dbname": "CSI_Maker00001439.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001439.fasta",
  "number-of-letters": 11898,
  "number-of-sequences": 63,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 70427,
  "bytes-to-cache": 3895,
  "files": [
    "CSI_Maker00001439.fasta.ndb",
    "CSI_Maker00001439.fasta.nhr",
    "CSI_Maker00001439.fasta.nin",
    "CSI_Maker00001439.fasta.nog",
    "CSI_Maker00001439.fasta.nos",
    "CSI_Maker00001439.fasta.not",
    "CSI_Maker00001439.fasta.nsq",
    "CSI_Maker00001439.fasta.ntf",
    "CSI_Maker00001439.fasta.nto"
  ]
}
