{
  "version": "1.2",
  "dbname": "CSI_Maker00000522.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000522.fasta",
  "number-of-letters": 80901,
  "number-of-sequences": 86,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 95818,
  "bytes-to-cache": 21746,
  "files": [
    "CSI_Maker00000522.fasta.ndb",
    "CSI_Maker00000522.fasta.nhr",
    "CSI_Maker00000522.fasta.nin",
    "CSI_Maker00000522.fasta.nog",
    "CSI_Maker00000522.fasta.nos",
    "CSI_Maker00000522.fasta.not",
    "CSI_Maker00000522.fasta.nsq",
    "CSI_Maker00000522.fasta.ntf",
    "CSI_Maker00000522.fasta.nto"
  ]
}
