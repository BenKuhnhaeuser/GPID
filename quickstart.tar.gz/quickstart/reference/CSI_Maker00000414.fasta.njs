{
  "version": "1.2",
  "dbname": "CSI_Maker00000414.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000414.fasta",
  "number-of-letters": 18225,
  "number-of-sequences": 82,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 79200,
  "bytes-to-cache": 5728,
  "files": [
    "CSI_Maker00000414.fasta.ndb",
    "CSI_Maker00000414.fasta.nhr",
    "CSI_Maker00000414.fasta.nin",
    "CSI_Maker00000414.fasta.nog",
    "CSI_Maker00000414.fasta.nos",
    "CSI_Maker00000414.fasta.not",
    "CSI_Maker00000414.fasta.nsq",
    "CSI_Maker00000414.fasta.ntf",
    "CSI_Maker00000414.fasta.nto"
  ]
}
