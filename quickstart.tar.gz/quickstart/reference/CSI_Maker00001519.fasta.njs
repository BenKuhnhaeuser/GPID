{
  "version": "1.2",
  "dbname": "CSI_Maker00001519.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001519.fasta",
  "number-of-letters": 12516,
  "number-of-sequences": 60,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 70160,
  "bytes-to-cache": 4020,
  "files": [
    "CSI_Maker00001519.fasta.ndb",
    "CSI_Maker00001519.fasta.nhr",
    "CSI_Maker00001519.fasta.nin",
    "CSI_Maker00001519.fasta.nog",
    "CSI_Maker00001519.fasta.nos",
    "CSI_Maker00001519.fasta.not",
    "CSI_Maker00001519.fasta.nsq",
    "CSI_Maker00001519.fasta.ntf",
    "CSI_Maker00001519.fasta.nto"
  ]
}
