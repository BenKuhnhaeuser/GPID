{
  "version": "1.2",
  "dbname": "CSI_Maker00000611.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000611.fasta",
  "number-of-letters": 119370,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 106181,
  "bytes-to-cache": 31961,
  "files": [
    "CSI_Maker00000611.fasta.ndb",
    "CSI_Maker00000611.fasta.nhr",
    "CSI_Maker00000611.fasta.nin",
    "CSI_Maker00000611.fasta.nog",
    "CSI_Maker00000611.fasta.nos",
    "CSI_Maker00000611.fasta.not",
    "CSI_Maker00000611.fasta.nsq",
    "CSI_Maker00000611.fasta.ntf",
    "CSI_Maker00000611.fasta.nto"
  ]
}
