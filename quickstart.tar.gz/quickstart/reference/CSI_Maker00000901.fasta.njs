{
  "version": "1.2",
  "dbname": "CSI_Maker00000901.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000901.fasta",
  "number-of-letters": 48564,
  "number-of-sequences": 83,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 87116,
  "bytes-to-cache": 13490,
  "files": [
    "CSI_Maker00000901.fasta.ndb",
    "CSI_Maker00000901.fasta.nhr",
    "CSI_Maker00000901.fasta.nin",
    "CSI_Maker00000901.fasta.nog",
    "CSI_Maker00000901.fasta.nos",
    "CSI_Maker00000901.fasta.not",
    "CSI_Maker00000901.fasta.nsq",
    "CSI_Maker00000901.fasta.ntf",
    "CSI_Maker00000901.fasta.nto"
  ]
}
