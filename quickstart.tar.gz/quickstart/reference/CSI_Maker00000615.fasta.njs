{
  "version": "1.2",
  "dbname": "CSI_Maker00000615.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000615.fasta",
  "number-of-letters": 109350,
  "number-of-sequences": 89,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 103417,
  "bytes-to-cache": 28895,
  "files": [
    "CSI_Maker00000615.fasta.ndb",
    "CSI_Maker00000615.fasta.nhr",
    "CSI_Maker00000615.fasta.nin",
    "CSI_Maker00000615.fasta.nog",
    "CSI_Maker00000615.fasta.nos",
    "CSI_Maker00000615.fasta.not",
    "CSI_Maker00000615.fasta.nsq",
    "CSI_Maker00000615.fasta.ntf",
    "CSI_Maker00000615.fasta.nto"
  ]
}
