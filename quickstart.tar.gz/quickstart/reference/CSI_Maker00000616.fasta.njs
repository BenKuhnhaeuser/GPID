{
  "version": "1.2",
  "dbname": "CSI_Maker00000616.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000616.fasta",
  "number-of-letters": 12276,
  "number-of-sequences": 33,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 57682,
  "bytes-to-cache": 3630,
  "files": [
    "CSI_Maker00000616.fasta.ndb",
    "CSI_Maker00000616.fasta.nhr",
    "CSI_Maker00000616.fasta.nin",
    "CSI_Maker00000616.fasta.nog",
    "CSI_Maker00000616.fasta.nos",
    "CSI_Maker00000616.fasta.not",
    "CSI_Maker00000616.fasta.nsq",
    "CSI_Maker00000616.fasta.ntf",
    "CSI_Maker00000616.fasta.nto"
  ]
}
