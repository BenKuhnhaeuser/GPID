{
  "version": "1.2",
  "dbname": "CSI_Maker00001421.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001421.fasta",
  "number-of-letters": 72225,
  "number-of-sequences": 77,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 93335,
  "bytes-to-cache": 20585,
  "files": [
    "CSI_Maker00001421.fasta.ndb",
    "CSI_Maker00001421.fasta.nhr",
    "CSI_Maker00001421.fasta.nin",
    "CSI_Maker00001421.fasta.nog",
    "CSI_Maker00001421.fasta.nos",
    "CSI_Maker00001421.fasta.not",
    "CSI_Maker00001421.fasta.nsq",
    "CSI_Maker00001421.fasta.ntf",
    "CSI_Maker00001421.fasta.nto"
  ]
}
