{
  "version": "1.2",
  "dbname": "CSI_Maker00001155.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001155.fasta",
  "number-of-letters": 74892,
  "number-of-sequences": 82,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 94306,
  "bytes-to-cache": 20818,
  "files": [
    "CSI_Maker00001155.fasta.ndb",
    "CSI_Maker00001155.fasta.nhr",
    "CSI_Maker00001155.fasta.nin",
    "CSI_Maker00001155.fasta.nog",
    "CSI_Maker00001155.fasta.nos",
    "CSI_Maker00001155.fasta.not",
    "CSI_Maker00001155.fasta.nsq",
    "CSI_Maker00001155.fasta.ntf",
    "CSI_Maker00001155.fasta.nto"
  ]
}
