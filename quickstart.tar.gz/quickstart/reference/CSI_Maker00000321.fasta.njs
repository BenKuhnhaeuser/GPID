{
  "version": "1.2",
  "dbname": "CSI_Maker00000321.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000321.fasta",
  "number-of-letters": 128538,
  "number-of-sequences": 86,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 108834,
  "bytes-to-cache": 34754,
  "files": [
    "CSI_Maker00000321.fasta.ndb",
    "CSI_Maker00000321.fasta.nhr",
    "CSI_Maker00000321.fasta.nin",
    "CSI_Maker00000321.fasta.nog",
    "CSI_Maker00000321.fasta.nos",
    "CSI_Maker00000321.fasta.not",
    "CSI_Maker00000321.fasta.nsq",
    "CSI_Maker00000321.fasta.ntf",
    "CSI_Maker00000321.fasta.nto"
  ]
}
