{
  "version": "1.2",
  "dbname": "CSI_Maker00000591.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000591.fasta",
  "number-of-letters": 30177,
  "number-of-sequences": 85,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 82787,
  "bytes-to-cache": 8867,
  "files": [
    "CSI_Maker00000591.fasta.ndb",
    "CSI_Maker00000591.fasta.nhr",
    "CSI_Maker00000591.fasta.nin",
    "CSI_Maker00000591.fasta.nog",
    "CSI_Maker00000591.fasta.nos",
    "CSI_Maker00000591.fasta.not",
    "CSI_Maker00000591.fasta.nsq",
    "CSI_Maker00000591.fasta.ntf",
    "CSI_Maker00000591.fasta.nto"
  ]
}
