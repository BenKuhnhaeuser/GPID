{
  "version": "1.2",
  "dbname": "CSI_Maker00001291.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001291.fasta",
  "number-of-letters": 122001,
  "number-of-sequences": 90,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 108335,
  "bytes-to-cache": 33651,
  "files": [
    "CSI_Maker00001291.fasta.ndb",
    "CSI_Maker00001291.fasta.nhr",
    "CSI_Maker00001291.fasta.nin",
    "CSI_Maker00001291.fasta.nog",
    "CSI_Maker00001291.fasta.nos",
    "CSI_Maker00001291.fasta.not",
    "CSI_Maker00001291.fasta.nsq",
    "CSI_Maker00001291.fasta.ntf",
    "CSI_Maker00001291.fasta.nto"
  ]
}
