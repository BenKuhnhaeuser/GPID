{
  "version": "1.2",
  "dbname": "CSI_Maker00000787.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000787.fasta",
  "number-of-letters": 72762,
  "number-of-sequences": 77,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 92737,
  "bytes-to-cache": 19997,
  "files": [
    "CSI_Maker00000787.fasta.ndb",
    "CSI_Maker00000787.fasta.nhr",
    "CSI_Maker00000787.fasta.nin",
    "CSI_Maker00000787.fasta.nog",
    "CSI_Maker00000787.fasta.nos",
    "CSI_Maker00000787.fasta.not",
    "CSI_Maker00000787.fasta.nsq",
    "CSI_Maker00000787.fasta.ntf",
    "CSI_Maker00000787.fasta.nto"
  ]
}
