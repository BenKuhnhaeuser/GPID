{
  "version": "1.2",
  "dbname": "CSI_Maker00000266.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000266.fasta",
  "number-of-letters": 3399,
  "number-of-sequences": 20,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 53345,
  "bytes-to-cache": 1239,
  "files": [
    "CSI_Maker00000266.fasta.ndb",
    "CSI_Maker00000266.fasta.nhr",
    "CSI_Maker00000266.fasta.nin",
    "CSI_Maker00000266.fasta.nog",
    "CSI_Maker00000266.fasta.nos",
    "CSI_Maker00000266.fasta.not",
    "CSI_Maker00000266.fasta.nsq",
    "CSI_Maker00000266.fasta.ntf",
    "CSI_Maker00000266.fasta.nto"
  ]
}
