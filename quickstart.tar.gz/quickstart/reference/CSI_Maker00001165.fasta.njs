{
  "version": "1.2",
  "dbname": "CSI_Maker00001165.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001165.fasta",
  "number-of-letters": 82428,
  "number-of-sequences": 82,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 96248,
  "bytes-to-cache": 22768,
  "files": [
    "CSI_Maker00001165.fasta.ndb",
    "CSI_Maker00001165.fasta.nhr",
    "CSI_Maker00001165.fasta.nin",
    "CSI_Maker00001165.fasta.nog",
    "CSI_Maker00001165.fasta.nos",
    "CSI_Maker00001165.fasta.not",
    "CSI_Maker00001165.fasta.nsq",
    "CSI_Maker00001165.fasta.ntf",
    "CSI_Maker00001165.fasta.nto"
  ]
}
