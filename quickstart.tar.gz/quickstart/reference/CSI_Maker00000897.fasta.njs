{
  "version": "1.2",
  "dbname": "CSI_Maker00000897.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000897.fasta",
  "number-of-letters": 28728,
  "number-of-sequences": 83,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 82003,
  "bytes-to-cache": 8387,
  "files": [
    "CSI_Maker00000897.fasta.ndb",
    "CSI_Maker00000897.fasta.nhr",
    "CSI_Maker00000897.fasta.nin",
    "CSI_Maker00000897.fasta.nog",
    "CSI_Maker00000897.fasta.nos",
    "CSI_Maker00000897.fasta.not",
    "CSI_Maker00000897.fasta.nsq",
    "CSI_Maker00000897.fasta.ntf",
    "CSI_Maker00000897.fasta.nto"
  ]
}
