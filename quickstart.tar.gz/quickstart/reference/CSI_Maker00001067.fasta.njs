{
  "version": "1.2",
  "dbname": "CSI_Maker00001067.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001067.fasta",
  "number-of-letters": 87378,
  "number-of-sequences": 83,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 97121,
  "bytes-to-cache": 23513,
  "files": [
    "CSI_Maker00001067.fasta.ndb",
    "CSI_Maker00001067.fasta.nhr",
    "CSI_Maker00001067.fasta.nin",
    "CSI_Maker00001067.fasta.nog",
    "CSI_Maker00001067.fasta.nos",
    "CSI_Maker00001067.fasta.not",
    "CSI_Maker00001067.fasta.nsq",
    "CSI_Maker00001067.fasta.ntf",
    "CSI_Maker00001067.fasta.nto"
  ]
}
