{
  "version": "1.2",
  "dbname": "CSI_Maker00001303.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001303.fasta",
  "number-of-letters": 53601,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 89413,
  "bytes-to-cache": 15193,
  "files": [
    "CSI_Maker00001303.fasta.ndb",
    "CSI_Maker00001303.fasta.nhr",
    "CSI_Maker00001303.fasta.nin",
    "CSI_Maker00001303.fasta.nog",
    "CSI_Maker00001303.fasta.nos",
    "CSI_Maker00001303.fasta.not",
    "CSI_Maker00001303.fasta.nsq",
    "CSI_Maker00001303.fasta.ntf",
    "CSI_Maker00001303.fasta.nto"
  ]
}
