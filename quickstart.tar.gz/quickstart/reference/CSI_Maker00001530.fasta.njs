{
  "version": "1.2",
  "dbname": "CSI_Maker00001530.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001530.fasta",
  "number-of-letters": 100680,
  "number-of-sequences": 86,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 100608,
  "bytes-to-cache": 26542,
  "files": [
    "CSI_Maker00001530.fasta.ndb",
    "CSI_Maker00001530.fasta.nhr",
    "CSI_Maker00001530.fasta.nin",
    "CSI_Maker00001530.fasta.nog",
    "CSI_Maker00001530.fasta.nos",
    "CSI_Maker00001530.fasta.not",
    "CSI_Maker00001530.fasta.nsq",
    "CSI_Maker00001530.fasta.ntf",
    "CSI_Maker00001530.fasta.nto"
  ]
}
