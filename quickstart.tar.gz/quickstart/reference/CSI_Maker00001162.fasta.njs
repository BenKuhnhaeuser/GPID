{
  "version": "1.2",
  "dbname": "CSI_Maker00001162.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001162.fasta",
  "number-of-letters": 29352,
  "number-of-sequences": 72,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 76826,
  "bytes-to-cache": 8924,
  "files": [
    "CSI_Maker00001162.fasta.ndb",
    "CSI_Maker00001162.fasta.nhr",
    "CSI_Maker00001162.fasta.nin",
    "CSI_Maker00001162.fasta.nog",
    "CSI_Maker00001162.fasta.nos",
    "CSI_Maker00001162.fasta.not",
    "CSI_Maker00001162.fasta.nsq",
    "CSI_Maker00001162.fasta.ntf",
    "CSI_Maker00001162.fasta.nto"
  ]
}
