{
  "version": "1.2",
  "dbname": "CSI_Maker00001368.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001368.fasta",
  "number-of-letters": 70899,
  "number-of-sequences": 75,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 88077,
  "bytes-to-cache": 19727,
  "files": [
    "CSI_Maker00001368.fasta.ndb",
    "CSI_Maker00001368.fasta.nhr",
    "CSI_Maker00001368.fasta.nin",
    "CSI_Maker00001368.fasta.nog",
    "CSI_Maker00001368.fasta.nos",
    "CSI_Maker00001368.fasta.not",
    "CSI_Maker00001368.fasta.nsq",
    "CSI_Maker00001368.fasta.ntf",
    "CSI_Maker00001368.fasta.nto"
  ]
}
