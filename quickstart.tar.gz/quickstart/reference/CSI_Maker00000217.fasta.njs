{
  "version": "1.2",
  "dbname": "CSI_Maker00000217.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000217.fasta",
  "number-of-letters": 15192,
  "number-of-sequences": 57,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 70384,
  "bytes-to-cache": 4662,
  "files": [
    "CSI_Maker00000217.fasta.ndb",
    "CSI_Maker00000217.fasta.nhr",
    "CSI_Maker00000217.fasta.nin",
    "CSI_Maker00000217.fasta.nog",
    "CSI_Maker00000217.fasta.nos",
    "CSI_Maker00000217.fasta.not",
    "CSI_Maker00000217.fasta.nsq",
    "CSI_Maker00000217.fasta.ntf",
    "CSI_Maker00000217.fasta.nto"
  ]
}
