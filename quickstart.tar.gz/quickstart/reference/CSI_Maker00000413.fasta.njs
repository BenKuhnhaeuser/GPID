{
  "version": "1.2",
  "dbname": "CSI_Maker00000413.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000413.fasta",
  "number-of-letters": 169284,
  "number-of-sequences": 85,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 119416,
  "bytes-to-cache": 45482,
  "files": [
    "CSI_Maker00000413.fasta.ndb",
    "CSI_Maker00000413.fasta.nhr",
    "CSI_Maker00000413.fasta.nin",
    "CSI_Maker00000413.fasta.nog",
    "CSI_Maker00000413.fasta.nos",
    "CSI_Maker00000413.fasta.not",
    "CSI_Maker00000413.fasta.nsq",
    "CSI_Maker00000413.fasta.ntf",
    "CSI_Maker00000413.fasta.nto"
  ]
}
