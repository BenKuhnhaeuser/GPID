{
  "version": "1.2",
  "dbname": "CSI_Maker00000798.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000798.fasta",
  "number-of-letters": 136512,
  "number-of-sequences": 83,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 110182,
  "bytes-to-cache": 36560,
  "files": [
    "CSI_Maker00000798.fasta.ndb",
    "CSI_Maker00000798.fasta.nhr",
    "CSI_Maker00000798.fasta.nin",
    "CSI_Maker00000798.fasta.nog",
    "CSI_Maker00000798.fasta.nos",
    "CSI_Maker00000798.fasta.not",
    "CSI_Maker00000798.fasta.nsq",
    "CSI_Maker00000798.fasta.ntf",
    "CSI_Maker00000798.fasta.nto"
  ]
}
