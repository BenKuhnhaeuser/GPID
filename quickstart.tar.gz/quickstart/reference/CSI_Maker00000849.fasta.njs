{
  "version": "1.2",
  "dbname": "CSI_Maker00000849.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000849.fasta",
  "number-of-letters": 20343,
  "number-of-sequences": 62,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 72485,
  "bytes-to-cache": 6009,
  "files": [
    "CSI_Maker00000849.fasta.ndb",
    "CSI_Maker00000849.fasta.nhr",
    "CSI_Maker00000849.fasta.nin",
    "CSI_Maker00000849.fasta.nog",
    "CSI_Maker00000849.fasta.nos",
    "CSI_Maker00000849.fasta.not",
    "CSI_Maker00000849.fasta.nsq",
    "CSI_Maker00000849.fasta.ntf",
    "CSI_Maker00000849.fasta.nto"
  ]
}
