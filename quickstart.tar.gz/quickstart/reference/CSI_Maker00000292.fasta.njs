{
  "version": "1.2",
  "dbname": "CSI_Maker00000292.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000292.fasta",
  "number-of-letters": 79797,
  "number-of-sequences": 88,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 95771,
  "bytes-to-cache": 21395,
  "files": [
    "CSI_Maker00000292.fasta.ndb",
    "CSI_Maker00000292.fasta.nhr",
    "CSI_Maker00000292.fasta.nin",
    "CSI_Maker00000292.fasta.nog",
    "CSI_Maker00000292.fasta.nos",
    "CSI_Maker00000292.fasta.not",
    "CSI_Maker00000292.fasta.nsq",
    "CSI_Maker00000292.fasta.ntf",
    "CSI_Maker00000292.fasta.nto"
  ]
}
