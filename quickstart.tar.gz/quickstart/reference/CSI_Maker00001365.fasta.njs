{
  "version": "1.2",
  "dbname": "CSI_Maker00001365.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001365.fasta",
  "number-of-letters": 33732,
  "number-of-sequences": 76,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 82195,
  "bytes-to-cache": 9627,
  "files": [
    "CSI_Maker00001365.fasta.ndb",
    "CSI_Maker00001365.fasta.nhr",
    "CSI_Maker00001365.fasta.nin",
    "CSI_Maker00001365.fasta.nog",
    "CSI_Maker00001365.fasta.nos",
    "CSI_Maker00001365.fasta.not",
    "CSI_Maker00001365.fasta.nsq",
    "CSI_Maker00001365.fasta.ntf",
    "CSI_Maker00001365.fasta.nto"
  ]
}
