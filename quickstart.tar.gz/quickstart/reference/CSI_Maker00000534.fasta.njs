{
  "version": "1.2",
  "dbname": "CSI_Maker00000534.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000534.fasta",
  "number-of-letters": 132795,
  "number-of-sequences": 86,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 109747,
  "bytes-to-cache": 35667,
  "files": [
    "CSI_Maker00000534.fasta.ndb",
    "CSI_Maker00000534.fasta.nhr",
    "CSI_Maker00000534.fasta.nin",
    "CSI_Maker00000534.fasta.nog",
    "CSI_Maker00000534.fasta.nos",
    "CSI_Maker00000534.fasta.not",
    "CSI_Maker00000534.fasta.nsq",
    "CSI_Maker00000534.fasta.ntf",
    "CSI_Maker00000534.fasta.nto"
  ]
}
