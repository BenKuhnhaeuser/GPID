{
  "version": "1.2",
  "dbname": "CSI_Maker00000199.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000199.fasta",
  "number-of-letters": 294,
  "number-of-sequences": 1,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 49585,
  "bytes-to-cache": 227,
  "files": [
    "CSI_Maker00000199.fasta.ndb",
    "CSI_Maker00000199.fasta.nhr",
    "CSI_Maker00000199.fasta.nin",
    "CSI_Maker00000199.fasta.nog",
    "CSI_Maker00000199.fasta.nos",
    "CSI_Maker00000199.fasta.not",
    "CSI_Maker00000199.fasta.nsq",
    "CSI_Maker00000199.fasta.ntf",
    "CSI_Maker00000199.fasta.nto"
  ]
}
