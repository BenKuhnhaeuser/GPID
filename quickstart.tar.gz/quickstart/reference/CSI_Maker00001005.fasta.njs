{
  "version": "1.2",
  "dbname": "CSI_Maker00001005.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001005.fasta",
  "number-of-letters": 17781,
  "number-of-sequences": 69,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 72984,
  "bytes-to-cache": 5490,
  "files": [
    "CSI_Maker00001005.fasta.ndb",
    "CSI_Maker00001005.fasta.nhr",
    "CSI_Maker00001005.fasta.nin",
    "CSI_Maker00001005.fasta.nog",
    "CSI_Maker00001005.fasta.nos",
    "CSI_Maker00001005.fasta.not",
    "CSI_Maker00001005.fasta.nsq",
    "CSI_Maker00001005.fasta.ntf",
    "CSI_Maker00001005.fasta.nto"
  ]
}
