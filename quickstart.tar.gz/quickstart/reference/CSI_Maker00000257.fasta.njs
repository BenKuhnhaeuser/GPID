{
  "version": "1.2",
  "dbname": "CSI_Maker00000257.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000257.fasta",
  "number-of-letters": 25677,
  "number-of-sequences": 81,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 80911,
  "bytes-to-cache": 7587,
  "files": [
    "CSI_Maker00000257.fasta.ndb",
    "CSI_Maker00000257.fasta.nhr",
    "CSI_Maker00000257.fasta.nin",
    "CSI_Maker00000257.fasta.nog",
    "CSI_Maker00000257.fasta.nos",
    "CSI_Maker00000257.fasta.not",
    "CSI_Maker00000257.fasta.nsq",
    "CSI_Maker00000257.fasta.ntf",
    "CSI_Maker00000257.fasta.nto"
  ]
}
