{
  "version": "1.2",
  "dbname": "CSI_Maker00000229.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000229.fasta",
  "number-of-letters": 141114,
  "number-of-sequences": 89,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 112493,
  "bytes-to-cache": 37971,
  "files": [
    "CSI_Maker00000229.fasta.ndb",
    "CSI_Maker00000229.fasta.nhr",
    "CSI_Maker00000229.fasta.nin",
    "CSI_Maker00000229.fasta.nog",
    "CSI_Maker00000229.fasta.nos",
    "CSI_Maker00000229.fasta.not",
    "CSI_Maker00000229.fasta.nsq",
    "CSI_Maker00000229.fasta.ntf",
    "CSI_Maker00000229.fasta.nto"
  ]
}
