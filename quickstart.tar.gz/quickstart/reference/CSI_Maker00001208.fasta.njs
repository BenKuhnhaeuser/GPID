{
  "version": "1.2",
  "dbname": "CSI_Maker00001208.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001208.fasta",
  "number-of-letters": 11865,
  "number-of-sequences": 74,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 72275,
  "bytes-to-cache": 4065,
  "files": [
    "CSI_Maker00001208.fasta.ndb",
    "CSI_Maker00001208.fasta.nhr",
    "CSI_Maker00001208.fasta.nin",
    "CSI_Maker00001208.fasta.nog",
    "CSI_Maker00001208.fasta.nos",
    "CSI_Maker00001208.fasta.not",
    "CSI_Maker00001208.fasta.nsq",
    "CSI_Maker00001208.fasta.ntf",
    "CSI_Maker00001208.fasta.nto"
  ]
}
