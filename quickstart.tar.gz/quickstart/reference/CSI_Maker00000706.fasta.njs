{
  "version": "1.2",
  "dbname": "CSI_Maker00000706.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000706.fasta",
  "number-of-letters": 13122,
  "number-of-sequences": 38,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 66878,
  "bytes-to-cache": 3916,
  "files": [
    "CSI_Maker00000706.fasta.ndb",
    "CSI_Maker00000706.fasta.nhr",
    "CSI_Maker00000706.fasta.nin",
    "CSI_Maker00000706.fasta.nog",
    "CSI_Maker00000706.fasta.nos",
    "CSI_Maker00000706.fasta.not",
    "CSI_Maker00000706.fasta.nsq",
    "CSI_Maker00000706.fasta.ntf",
    "CSI_Maker00000706.fasta.nto"
  ]
}
