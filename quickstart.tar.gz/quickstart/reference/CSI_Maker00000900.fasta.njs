{
  "version": "1.2",
  "dbname": "CSI_Maker00000900.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000900.fasta",
  "number-of-letters": 82323,
  "number-of-sequences": 78,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 94931,
  "bytes-to-cache": 22013,
  "files": [
    "CSI_Maker00000900.fasta.ndb",
    "CSI_Maker00000900.fasta.nhr",
    "CSI_Maker00000900.fasta.nin",
    "CSI_Maker00000900.fasta.nog",
    "CSI_Maker00000900.fasta.nos",
    "CSI_Maker00000900.fasta.not",
    "CSI_Maker00000900.fasta.nsq",
    "CSI_Maker00000900.fasta.ntf",
    "CSI_Maker00000900.fasta.nto"
  ]
}
