{
  "version": "1.2",
  "dbname": "CSI_Maker00000913.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000913.fasta",
  "number-of-letters": 78795,
  "number-of-sequences": 79,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 95070,
  "bytes-to-cache": 22046,
  "files": [
    "CSI_Maker00000913.fasta.ndb",
    "CSI_Maker00000913.fasta.nhr",
    "CSI_Maker00000913.fasta.nin",
    "CSI_Maker00000913.fasta.nog",
    "CSI_Maker00000913.fasta.nos",
    "CSI_Maker00000913.fasta.not",
    "CSI_Maker00000913.fasta.nsq",
    "CSI_Maker00000913.fasta.ntf",
    "CSI_Maker00000913.fasta.nto"
  ]
}
