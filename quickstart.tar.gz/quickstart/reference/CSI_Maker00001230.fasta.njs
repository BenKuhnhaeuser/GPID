{
  "version": "1.2",
  "dbname": "CSI_Maker00001230.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001230.fasta",
  "number-of-letters": 6927,
  "number-of-sequences": 30,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 55863,
  "bytes-to-cache": 2255,
  "files": [
    "CSI_Maker00001230.fasta.ndb",
    "CSI_Maker00001230.fasta.nhr",
    "CSI_Maker00001230.fasta.nin",
    "CSI_Maker00001230.fasta.nog",
    "CSI_Maker00001230.fasta.nos",
    "CSI_Maker00001230.fasta.not",
    "CSI_Maker00001230.fasta.nsq",
    "CSI_Maker00001230.fasta.ntf",
    "CSI_Maker00001230.fasta.nto"
  ]
}
