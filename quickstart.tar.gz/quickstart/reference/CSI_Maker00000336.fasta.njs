{
  "version": "1.2",
  "dbname": "CSI_Maker00000336.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000336.fasta",
  "number-of-letters": 108942,
  "number-of-sequences": 88,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 103780,
  "bytes-to-cache": 29404,
  "files": [
    "CSI_Maker00000336.fasta.ndb",
    "CSI_Maker00000336.fasta.nhr",
    "CSI_Maker00000336.fasta.nin",
    "CSI_Maker00000336.fasta.nog",
    "CSI_Maker00000336.fasta.nos",
    "CSI_Maker00000336.fasta.not",
    "CSI_Maker00000336.fasta.nsq",
    "CSI_Maker00000336.fasta.ntf",
    "CSI_Maker00000336.fasta.nto"
  ]
}
