{
  "version": "1.2",
  "dbname": "CSI_Maker00000879.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000879.fasta",
  "number-of-letters": 59700,
  "number-of-sequences": 81,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 89668,
  "bytes-to-cache": 16346,
  "files": [
    "CSI_Maker00000879.fasta.ndb",
    "CSI_Maker00000879.fasta.nhr",
    "CSI_Maker00000879.fasta.nin",
    "CSI_Maker00000879.fasta.nog",
    "CSI_Maker00000879.fasta.nos",
    "CSI_Maker00000879.fasta.not",
    "CSI_Maker00000879.fasta.nsq",
    "CSI_Maker00000879.fasta.ntf",
    "CSI_Maker00000879.fasta.nto"
  ]
}
