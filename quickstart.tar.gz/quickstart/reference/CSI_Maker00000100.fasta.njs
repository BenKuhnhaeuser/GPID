{
  "version": "1.2",
  "dbname": "CSI_Maker00000100.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000100.fasta",
  "number-of-letters": 122166,
  "number-of-sequences": 85,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 107500,
  "bytes-to-cache": 33588,
  "files": [
    "CSI_Maker00000100.fasta.ndb",
    "CSI_Maker00000100.fasta.nhr",
    "CSI_Maker00000100.fasta.nin",
    "CSI_Maker00000100.fasta.nog",
    "CSI_Maker00000100.fasta.nos",
    "CSI_Maker00000100.fasta.not",
    "CSI_Maker00000100.fasta.nsq",
    "CSI_Maker00000100.fasta.ntf",
    "CSI_Maker00000100.fasta.nto"
  ]
}
