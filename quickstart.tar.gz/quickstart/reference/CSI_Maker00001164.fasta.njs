{
  "version": "1.2",
  "dbname": "CSI_Maker00001164.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001164.fasta",
  "number-of-letters": 97359,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 100258,
  "bytes-to-cache": 26038,
  "files": [
    "CSI_Maker00001164.fasta.ndb",
    "CSI_Maker00001164.fasta.nhr",
    "CSI_Maker00001164.fasta.nin",
    "CSI_Maker00001164.fasta.nog",
    "CSI_Maker00001164.fasta.nos",
    "CSI_Maker00001164.fasta.not",
    "CSI_Maker00001164.fasta.nsq",
    "CSI_Maker00001164.fasta.ntf",
    "CSI_Maker00001164.fasta.nto"
  ]
}
