{
  "version": "1.2",
  "dbname": "CSI_Maker00000878.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000878.fasta",
  "number-of-letters": 89430,
  "number-of-sequences": 86,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 97817,
  "bytes-to-cache": 23745,
  "files": [
    "CSI_Maker00000878.fasta.ndb",
    "CSI_Maker00000878.fasta.nhr",
    "CSI_Maker00000878.fasta.nin",
    "CSI_Maker00000878.fasta.nog",
    "CSI_Maker00000878.fasta.nos",
    "CSI_Maker00000878.fasta.not",
    "CSI_Maker00000878.fasta.nsq",
    "CSI_Maker00000878.fasta.ntf",
    "CSI_Maker00000878.fasta.nto"
  ]
}
