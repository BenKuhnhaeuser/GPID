{
  "version": "1.2",
  "dbname": "CSI_Maker00000610.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000610.fasta",
  "number-of-letters": 46647,
  "number-of-sequences": 82,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 86304,
  "bytes-to-cache": 12838,
  "files": [
    "CSI_Maker00000610.fasta.ndb",
    "CSI_Maker00000610.fasta.nhr",
    "CSI_Maker00000610.fasta.nin",
    "CSI_Maker00000610.fasta.nog",
    "CSI_Maker00000610.fasta.nos",
    "CSI_Maker00000610.fasta.not",
    "CSI_Maker00000610.fasta.nsq",
    "CSI_Maker00000610.fasta.ntf",
    "CSI_Maker00000610.fasta.nto"
  ]
}
