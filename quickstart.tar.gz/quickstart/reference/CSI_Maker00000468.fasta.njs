{
  "version": "1.2",
  "dbname": "CSI_Maker00000468.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000468.fasta",
  "number-of-letters": 86094,
  "number-of-sequences": 80,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 96795,
  "bytes-to-cache": 23615,
  "files": [
    "CSI_Maker00000468.fasta.ndb",
    "CSI_Maker00000468.fasta.nhr",
    "CSI_Maker00000468.fasta.nin",
    "CSI_Maker00000468.fasta.nog",
    "CSI_Maker00000468.fasta.nos",
    "CSI_Maker00000468.fasta.not",
    "CSI_Maker00000468.fasta.nsq",
    "CSI_Maker00000468.fasta.ntf",
    "CSI_Maker00000468.fasta.nto"
  ]
}
