{
  "version": "1.2",
  "dbname": "CSI_Maker00000675.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000675.fasta",
  "number-of-letters": 106080,
  "number-of-sequences": 83,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 103058,
  "bytes-to-cache": 29436,
  "files": [
    "CSI_Maker00000675.fasta.ndb",
    "CSI_Maker00000675.fasta.nhr",
    "CSI_Maker00000675.fasta.nin",
    "CSI_Maker00000675.fasta.nog",
    "CSI_Maker00000675.fasta.nos",
    "CSI_Maker00000675.fasta.not",
    "CSI_Maker00000675.fasta.nsq",
    "CSI_Maker00000675.fasta.ntf",
    "CSI_Maker00000675.fasta.nto"
  ]
}
