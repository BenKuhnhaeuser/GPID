{
  "version": "1.2",
  "dbname": "CSI_Maker00000299.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000299.fasta",
  "number-of-letters": 42279,
  "number-of-sequences": 76,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 84497,
  "bytes-to-cache": 11921,
  "files": [
    "CSI_Maker00000299.fasta.ndb",
    "CSI_Maker00000299.fasta.nhr",
    "CSI_Maker00000299.fasta.nin",
    "CSI_Maker00000299.fasta.nog",
    "CSI_Maker00000299.fasta.nos",
    "CSI_Maker00000299.fasta.not",
    "CSI_Maker00000299.fasta.nsq",
    "CSI_Maker00000299.fasta.ntf",
    "CSI_Maker00000299.fasta.nto"
  ]
}
