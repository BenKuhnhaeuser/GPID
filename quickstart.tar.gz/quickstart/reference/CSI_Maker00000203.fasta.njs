{
  "version": "1.2",
  "dbname": "CSI_Maker00000203.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000203.fasta",
  "number-of-letters": 27861,
  "number-of-sequences": 83,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 81790,
  "bytes-to-cache": 8164,
  "files": [
    "CSI_Maker00000203.fasta.ndb",
    "CSI_Maker00000203.fasta.nhr",
    "CSI_Maker00000203.fasta.nin",
    "CSI_Maker00000203.fasta.nog",
    "CSI_Maker00000203.fasta.nos",
    "CSI_Maker00000203.fasta.not",
    "CSI_Maker00000203.fasta.nsq",
    "CSI_Maker00000203.fasta.ntf",
    "CSI_Maker00000203.fasta.nto"
  ]
}
