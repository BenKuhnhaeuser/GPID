{
  "version": "1.2",
  "dbname": "CSI_Maker00001385.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001385.fasta",
  "number-of-letters": 25467,
  "number-of-sequences": 65,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 74642,
  "bytes-to-cache": 7760,
  "files": [
    "CSI_Maker00001385.fasta.ndb",
    "CSI_Maker00001385.fasta.nhr",
    "CSI_Maker00001385.fasta.nin",
    "CSI_Maker00001385.fasta.nog",
    "CSI_Maker00001385.fasta.nos",
    "CSI_Maker00001385.fasta.not",
    "CSI_Maker00001385.fasta.nsq",
    "CSI_Maker00001385.fasta.ntf",
    "CSI_Maker00001385.fasta.nto"
  ]
}
