{
  "version": "1.2",
  "dbname": "CSI_Maker00001456.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001456.fasta",
  "number-of-letters": 14949,
  "number-of-sequences": 80,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 78062,
  "bytes-to-cache": 4892,
  "files": [
    "CSI_Maker00001456.fasta.ndb",
    "CSI_Maker00001456.fasta.nhr",
    "CSI_Maker00001456.fasta.nin",
    "CSI_Maker00001456.fasta.nog",
    "CSI_Maker00001456.fasta.nos",
    "CSI_Maker00001456.fasta.not",
    "CSI_Maker00001456.fasta.nsq",
    "CSI_Maker00001456.fasta.ntf",
    "CSI_Maker00001456.fasta.nto"
  ]
}
