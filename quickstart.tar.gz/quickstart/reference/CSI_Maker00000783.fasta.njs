{
  "version": "1.2",
  "dbname": "CSI_Maker00000783.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000783.fasta",
  "number-of-letters": 156075,
  "number-of-sequences": 90,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 115601,
  "bytes-to-cache": 40917,
  "files": [
    "CSI_Maker00000783.fasta.ndb",
    "CSI_Maker00000783.fasta.nhr",
    "CSI_Maker00000783.fasta.nin",
    "CSI_Maker00000783.fasta.nog",
    "CSI_Maker00000783.fasta.nos",
    "CSI_Maker00000783.fasta.not",
    "CSI_Maker00000783.fasta.nsq",
    "CSI_Maker00000783.fasta.ntf",
    "CSI_Maker00000783.fasta.nto"
  ]
}
