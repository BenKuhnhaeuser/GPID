{
  "version": "1.2",
  "dbname": "CSI_Maker00000551.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000551.fasta",
  "number-of-letters": 96639,
  "number-of-sequences": 85,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 99556,
  "bytes-to-cache": 25640,
  "files": [
    "CSI_Maker00000551.fasta.ndb",
    "CSI_Maker00000551.fasta.nhr",
    "CSI_Maker00000551.fasta.nin",
    "CSI_Maker00000551.fasta.nog",
    "CSI_Maker00000551.fasta.nos",
    "CSI_Maker00000551.fasta.not",
    "CSI_Maker00000551.fasta.nsq",
    "CSI_Maker00000551.fasta.ntf",
    "CSI_Maker00000551.fasta.nto"
  ]
}
