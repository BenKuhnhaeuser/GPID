{
  "version": "1.2",
  "dbname": "CSI_Maker00000221.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000221.fasta",
  "number-of-letters": 34842,
  "number-of-sequences": 76,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 82705,
  "bytes-to-cache": 10115,
  "files": [
    "CSI_Maker00000221.fasta.ndb",
    "CSI_Maker00000221.fasta.nhr",
    "CSI_Maker00000221.fasta.nin",
    "CSI_Maker00000221.fasta.nog",
    "CSI_Maker00000221.fasta.nos",
    "CSI_Maker00000221.fasta.not",
    "CSI_Maker00000221.fasta.nsq",
    "CSI_Maker00000221.fasta.ntf",
    "CSI_Maker00000221.fasta.nto"
  ]
}
