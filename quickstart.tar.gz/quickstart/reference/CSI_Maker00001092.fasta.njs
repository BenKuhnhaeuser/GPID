{
  "version": "1.2",
  "dbname": "CSI_Maker00001092.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001092.fasta",
  "number-of-letters": 128220,
  "number-of-sequences": 88,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 108062,
  "bytes-to-cache": 33686,
  "files": [
    "CSI_Maker00001092.fasta.ndb",
    "CSI_Maker00001092.fasta.nhr",
    "CSI_Maker00001092.fasta.nin",
    "CSI_Maker00001092.fasta.nog",
    "CSI_Maker00001092.fasta.nos",
    "CSI_Maker00001092.fasta.not",
    "CSI_Maker00001092.fasta.nsq",
    "CSI_Maker00001092.fasta.ntf",
    "CSI_Maker00001092.fasta.nto"
  ]
}
