{
  "version": "1.2",
  "dbname": "CSI_Maker00000222.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000222.fasta",
  "number-of-letters": 2529,
  "number-of-sequences": 15,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 52361,
  "bytes-to-cache": 987,
  "files": [
    "CSI_Maker00000222.fasta.ndb",
    "CSI_Maker00000222.fasta.nhr",
    "CSI_Maker00000222.fasta.nin",
    "CSI_Maker00000222.fasta.nog",
    "CSI_Maker00000222.fasta.nos",
    "CSI_Maker00000222.fasta.not",
    "CSI_Maker00000222.fasta.nsq",
    "CSI_Maker00000222.fasta.ntf",
    "CSI_Maker00000222.fasta.nto"
  ]
}
