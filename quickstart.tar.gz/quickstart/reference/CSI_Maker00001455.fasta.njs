{
  "version": "1.2",
  "dbname": "CSI_Maker00001455.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00001455.fasta",
  "number-of-letters": 39924,
  "number-of-sequences": 88,
  "last-updated": "2026-09-04T12:56:00",
  "number-of-volumes": 1,
  "bytes-total": 85635,
  "bytes-to-cache": 11259,
  "files": [
    "CSI_Maker00001455.fasta.ndb",
    "CSI_Maker00001455.fasta.nhr",
    "CSI_Maker00001455.fasta.nin",
    "CSI_Maker00001455.fasta.nog",
    "CSI_Maker00001455.fasta.nos",
    "CSI_Maker00001455.fasta.not",
    "CSI_Maker00001455.fasta.nsq",
    "CSI_Maker00001455.fasta.ntf",
    "CSI_Maker00001455.fasta.nto"
  ]
}
