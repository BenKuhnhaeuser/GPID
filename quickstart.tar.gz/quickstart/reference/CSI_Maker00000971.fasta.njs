{
  "version": "1.2",
  "dbname": "CSI_Maker00000971.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000971.fasta",
  "number-of-letters": 49788,
  "number-of-sequences": 81,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 87014,
  "bytes-to-cache": 13678,
  "files": [
    "CSI_Maker00000971.fasta.ndb",
    "CSI_Maker00000971.fasta.nhr",
    "CSI_Maker00000971.fasta.nin",
    "CSI_Maker00000971.fasta.nog",
    "CSI_Maker00000971.fasta.nos",
    "CSI_Maker00000971.fasta.not",
    "CSI_Maker00000971.fasta.nsq",
    "CSI_Maker00000971.fasta.ntf",
    "CSI_Maker00000971.fasta.nto"
  ]
}
