{
  "version": "1.2",
  "dbname": "CSI_Maker00000866.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000866.fasta",
  "number-of-letters": 109092,
  "number-of-sequences": 82,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 102728,
  "bytes-to-cache": 29240,
  "files": [
    "CSI_Maker00000866.fasta.ndb",
    "CSI_Maker00000866.fasta.nhr",
    "CSI_Maker00000866.fasta.nin",
    "CSI_Maker00000866.fasta.nog",
    "CSI_Maker00000866.fasta.nos",
    "CSI_Maker00000866.fasta.not",
    "CSI_Maker00000866.fasta.nsq",
    "CSI_Maker00000866.fasta.ntf",
    "CSI_Maker00000866.fasta.nto"
  ]
}
