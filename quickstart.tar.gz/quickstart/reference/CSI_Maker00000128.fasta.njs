{
  "version": "1.2",
  "dbname": "CSI_Maker00000128.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000128.fasta",
  "number-of-letters": 124164,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 106984,
  "bytes-to-cache": 32758,
  "files": [
    "CSI_Maker00000128.fasta.ndb",
    "CSI_Maker00000128.fasta.nhr",
    "CSI_Maker00000128.fasta.nin",
    "CSI_Maker00000128.fasta.nog",
    "CSI_Maker00000128.fasta.nos",
    "CSI_Maker00000128.fasta.not",
    "CSI_Maker00000128.fasta.nsq",
    "CSI_Maker00000128.fasta.ntf",
    "CSI_Maker00000128.fasta.nto"
  ]
}
