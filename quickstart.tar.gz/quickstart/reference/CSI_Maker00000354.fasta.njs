{
  "version": "1.2",
  "dbname": "CSI_Maker00000354.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000354.fasta",
  "number-of-letters": 155988,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 114774,
  "bytes-to-cache": 40550,
  "files": [
    "CSI_Maker00000354.fasta.ndb",
    "CSI_Maker00000354.fasta.nhr",
    "CSI_Maker00000354.fasta.nin",
    "CSI_Maker00000354.fasta.nog",
    "CSI_Maker00000354.fasta.nos",
    "CSI_Maker00000354.fasta.not",
    "CSI_Maker00000354.fasta.nsq",
    "CSI_Maker00000354.fasta.ntf",
    "CSI_Maker00000354.fasta.nto"
  ]
}
