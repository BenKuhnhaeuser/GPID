{
  "version": "1.2",
  "dbname": "CSI_Maker00000642.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000642.fasta",
  "number-of-letters": 46974,
  "number-of-sequences": 66,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 80296,
  "bytes-to-cache": 13254,
  "files": [
    "CSI_Maker00000642.fasta.ndb",
    "CSI_Maker00000642.fasta.nhr",
    "CSI_Maker00000642.fasta.nin",
    "CSI_Maker00000642.fasta.nog",
    "CSI_Maker00000642.fasta.nos",
    "CSI_Maker00000642.fasta.not",
    "CSI_Maker00000642.fasta.nsq",
    "CSI_Maker00000642.fasta.ntf",
    "CSI_Maker00000642.fasta.nto"
  ]
}
