{
  "version": "1.2",
  "dbname": "CSI_Maker00000811.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "reference/CSI_Maker00000811.fasta",
  "number-of-letters": 43674,
  "number-of-sequences": 87,
  "last-updated": "2026-09-04T12:55:00",
  "number-of-volumes": 1,
  "bytes-total": 86560,
  "bytes-to-cache": 12338,
  "files": [
    "CSI_Maker00000811.fasta.ndb",
    "CSI_Maker00000811.fasta.nhr",
    "CSI_Maker00000811.fasta.nin",
    "CSI_Maker00000811.fasta.nog",
    "CSI_Maker00000811.fasta.nos",
    "CSI_Maker00000811.fasta.not",
    "CSI_Maker00000811.fasta.nsq",
    "CSI_Maker00000811.fasta.ntf",
    "CSI_Maker00000811.fasta.nto"
  ]
}
